﻿using System.Windows.Forms;

namespace FileHandlingSystem
{
    public partial class AboutUs : Form
    {
        /// <summary>
        /// Constructor to show About us form
        /// </summary>
        public AboutUs()
        {
            InitializeComponent();
        }

        private void AboutUs_Load(object sender, System.EventArgs e)
        {
            richTextBox1.ReadOnly = true;

            // Fill the RichTextBox with text
            richTextBox1.Text = @"
                Welcome to our software File Handling System. 
                We take pride in crafting robust and user-friendly applications 
                that meet the needs of our clients. Below, we provide an overview 
                of our recent project, highlighting its architecture and key features.

                Project Overview:
                Our recent project involved the development of a data management 
                application with the following key requirements:

                - Layer Architecture: We implemented a scalable and maintainable 
                layer architecture to ensure separation of concerns and facilitate 
                future enhancements.
                - Binary File Generation: Data is stored in binary format for 
                efficient storage and retrieval, enhancing performance and data 
                security.
                - Grid View with Filtering: The application features a grid view 
                with filtering capabilities on each column, enabling users to 
                easily search and filter data based on their preferences.

                Architecture Overview:
                1. Presentation Layer: Our presentation layer comprises a 
                user-friendly interface developed using [choose appropriate GUI 
                framework]. It includes: Grid view with filtering options for each 
                column, allowing users to refine search results.
                2. Business Logic Layer: The business logic layer manages core 
                application logic, encompassing CRUD operations and data 
                processing. Key features include: Validation of input data against 
                business rules to maintain data consistency. Handling of filtering 
                operations to optimize data retrieval efficiency.
                3. Data Access Layer: Our data access layer interacts with the 
                underlying data storage mechanism, which involves: Reading from and 
                writing to binary files for efficient data storage. Serialization 
                and deserialization techniques to facilitate data storage and 
                    retrieval in binary format.
                4. Validation Layer: To ensure the reliability of user inputs, we 
                implemented a validation layer that: Enforces length constraints 
                and other business rules on user inputs. Provides clear error 
                messages or notifications for invalid inputs, enhancing user 
                experience.
            ";
        }
    }
}
