﻿using System;
using System.Windows.Forms;
using FileHandlingSystem.Resources;
using FileHandlingSystem.BL;
using FIleHandlingSystem.VO;

namespace FileHandlingSystem
{
    /// <summary>
    /// Class For Authentication Form
    /// </summary>
    public partial class AuthenticationForm : Form 
    {
        
        /// <summary>
        /// property to show if the user  is validated
        /// </summary>
        public bool validated = false;
        /// <summary>
        /// class object to use property of value layer object class
        /// </summary>
         private ValueLayerObject vlo;

        /// <summary>
        /// Default Construcctor whcih will be invoked when an object of this class is created
        /// </summary>
        public AuthenticationForm(ValueLayerObject vlo)
        {
            InitializeComponent();
            this.vlo = vlo;
        }

        private void frm_Authentication_Load(object sender, EventArgs e)
        {
            InitializeElements();
        }

        /// <summary>
        /// Initialize Elements of Form When the Form is Loaded
        /// </summary>
        private void InitializeElements()
        {
          
            foreach (UserTypes user in Enum.GetValues(typeof(UserTypes)))
            {
                cbx_usertype.Items.Add(user);
            }
            cbx_usertype.SelectedIndex = 0;
            textbox_password.PasswordChar = '*';
        }

       

        private void textbox_password_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                loginBtn_Click(sender, e);

                e.Handled = true;
            }
        }

        private void textbox_username_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                textbox_password.Focus();

                e.Handled = true;
            }
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {


            clsBusinessLogicBL bL = new clsBusinessLogicBL();
            AuthenticatorValueObject vo = new AuthenticatorValueObject();
            vo.username = textbox_username.Text;
            vo.password = textbox_password.Text;
            vo.userType = (UserTypes)cbx_usertype.SelectedIndex;

            if (bL.CheckValidUser(vo, vlo))
            {
               
                this.validated = true;

                vlo.userType = vo.userType;
                this.Close();
            }
            else
            {
               
                this.validated = false;
            }
        }
    }


}
