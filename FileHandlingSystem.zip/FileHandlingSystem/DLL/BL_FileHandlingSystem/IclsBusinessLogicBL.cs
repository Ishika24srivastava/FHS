﻿using FIleHandlingSystem.VO;

namespace FileHandlingSystem.BL
{
    public interface IclsBusinessLogicBL
    {
        bool CheckValidUser(AuthenticatorValueObject vo, ValueLayerObject vlo);
        bool Save(clsEmployeeVO vo, ValueLayerObject vlo);
        bool SetConfigurations(ValueLayerObject vlo);
    }
}