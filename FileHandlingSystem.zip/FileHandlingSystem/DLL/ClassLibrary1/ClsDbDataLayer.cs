﻿using System;
using FIleHandlingSystem.VO;
using System.Data.SqlClient;
using FileHandlingSystem.Resources;
using System.Security.Cryptography;
using System.Collections.Generic;

namespace FileHandlingSystem.DL
{
    /// <summary>
    /// Class to contains data layer method for connectivity 
    /// </summary>
    public class ClsDbDataLayer
    {

        // static string connectionString1 =  @"Data Source=ESKTOP-L8C9MNU;Database=FHP;Integrated Security=True;";
        private string connectionString;

        /// <summary>
        /// Function to Fetch Records from dataBase
        /// </summary>
        /// <param name="vlo"></param>
        /// <returns></returns>
        public bool GetRecordDataFromDB(ValueLayerObject vlo)
        {
            try
            {
                // Connect to the SQL Server database and retrieve data from the UserData table
                using (SqlConnection connection = new SqlConnection(vlo.connectionString))
                {
                    string sqlQuery = "SELECT * FROM Userdata";

                    SqlCommand command = new SqlCommand(sqlQuery, connection);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Read data from the database and populate UserData objects
                    while (reader.Read())
                    {
                        if (reader.HasRows)
                        {
                            EmployeeData userData = new EmployeeData
                            {
                                SerialNumber = (long)reader[0],
                                Prefix = (string)reader[1]?.ToString(),
                                FirstName = (string)reader[2]?.ToString(),
                                MiddleName = (string)reader[3]?.ToString(),
                                LastName = (string)reader[4]?.ToString(),
                                DateOfBirth = DateTime.Parse(reader[5]?.ToString()),
                                Qualification = (byte)reader[6],
                                CurrentCompany = (string)reader[7]?.ToString(),
                                JoiningDate = (DateTime)reader[8],
                                CurrentAddress = (string)reader[9]?.ToString()
                            };
                            string data = vlo.GenerateDataString(userData);
                            vlo.records.Add(data);
                        }

                    }
                    reader.Close();
                    connection.Dispose();
                    connection.Close();
                    return true;
                }
            }
            catch
            {
                return false;
            }

        }

        
        /// <summary>
        /// Method to Store the Record into Database
        /// </summary>
        /// <param name="vo">object of Value object class to check which query will be executed on database</param>
        /// <returns></returns>
        public bool StoreToDatabase(clsEmployeeVO vo, ValueLayerObject vlo)
        {
            this.connectionString = vlo.connectionString;
            if (vo.editMode == EditMode.Create)
            {
                if (InsertRecordIntoDB(vo.EmployeeData))
                {
                    return true;
                }
            }
            else if (vo.editMode == EditMode.Update)
            {
                if (UpdateRecordInDB(vo.EmployeeData))
                {
                    return true;
                }
            }
            else if (vo.editMode == EditMode.Delete)
            {
                if (DeleteRecordFromDB(vo.EmployeeData.SerialNumber.ToString()))
                {
                    return true;
                }
            }
            return false;
        }

        private bool InsertRecordIntoDB(EmployeeData vo)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string sqlQuery = @"INSERT INTO UserData (SerialNumber, Prefix, FirstName, MiddleName, LastName, DateOfBirth, Qualification, CurrentCompany, JoiningDate, CurrentAddress) 
                                VALUES (@SerialNumber, @Prefix, @FirstName, @MiddleName, @LastName, @DateOfBirth, @Qualification, @CurrentCompany, @JoiningDate, @CurrentAddress)";

                    SqlCommand command = new SqlCommand(sqlQuery, connection);
                    command.Parameters.AddWithValue("@SerialNumber", vo.SerialNumber);
                    command.Parameters.AddWithValue("@Prefix", vo.Prefix);
                    command.Parameters.AddWithValue("@FirstName", vo.FirstName);
                    command.Parameters.AddWithValue("@MiddleName", vo.MiddleName);
                    command.Parameters.AddWithValue("@LastName", vo.LastName);
                    command.Parameters.AddWithValue("@DateOfBirth", vo.DateOfBirth);
                    command.Parameters.AddWithValue("@Qualification", vo.Qualification);
                    command.Parameters.AddWithValue("@CurrentCompany", vo.CurrentCompany);
                    command.Parameters.AddWithValue("@JoiningDate", vo.JoiningDate);
                    command.Parameters.AddWithValue("@CurrentAddress", vo.CurrentAddress);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    connection.Dispose();
                    connection.Close();

                    return rowsAffected > 0;
                }
            }
            catch
            {
                return false;
            }
        }

        private bool UpdateRecordInDB(EmployeeData vo)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string sqlQuery = @"UPDATE UserData SET 
                                Prefix = @Prefix,
                                FirstName = @FirstName,
                                MiddleName = @MiddleName,
                                LastName = @LastName,
                                DateOfBirth = @DateOfBirth,
                                Qualification = @Qualification,
                                CurrentCompany = @CurrentCompany,
                                JoiningDate = @JoiningDate,
                                CurrentAddress = @CurrentAddress
                                WHERE SerialNumber = @SerialNumber";

                    SqlCommand command = new SqlCommand(sqlQuery, connection);
                    command.Parameters.AddWithValue("@SerialNumber", vo.SerialNumber);
                    command.Parameters.AddWithValue("@Prefix", vo.Prefix);
                    command.Parameters.AddWithValue("@FirstName", vo.FirstName);
                    command.Parameters.AddWithValue("@MiddleName", vo.MiddleName);
                    command.Parameters.AddWithValue("@LastName", vo.LastName);
                    command.Parameters.AddWithValue("@DateOfBirth", vo.DateOfBirth);
                    command.Parameters.AddWithValue("@Qualification", vo.Qualification);
                    command.Parameters.AddWithValue("@CurrentCompany", vo.CurrentCompany);
                    command.Parameters.AddWithValue("@JoiningDate", vo.JoiningDate);
                    command.Parameters.AddWithValue("@CurrentAddress", vo.CurrentAddress);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    connection.Dispose();
                    connection.Close();

                    return rowsAffected > 0;
                }
            }
            catch
            {
                return false;
            }
        }

        private bool DeleteRecordFromDB(string serialNumber)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string sqlQuery = @"DELETE FROM  Userdata WHERE SerialNumber = @SerialNumber";

                    SqlCommand command = new SqlCommand(sqlQuery, connection);
                    command.Parameters.AddWithValue("@SerialNumber", serialNumber);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    connection.Dispose();
                    connection.Close();

                    return rowsAffected > 0;
                }
            }
            catch
            {
                return false;
            }
        }

    }

    
}