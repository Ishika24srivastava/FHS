﻿using System;
using System.IO;
using System.Security;
using System.Text;
using FIleHandlingSystem.VO;
using FileHandlingSystem.Resources;

namespace FileHandlingSystem.DL
{

    /// <summary>
    /// partial class of Data Layer
    /// </summary>
    public partial class clsFileHandlingSystem 
    {
        private FileStream InputDataFile;

        /// <summary>
        /// Create A New flat file, Or Open A Existing File
        /// fetch the Records from the Exisiting file, If present and Inset them into Records variable of Value Object
        /// </summary>
        public bool CreateOrOpenFile(ValueLayerObject vlo)
        {
            if (vlo.dataStorageMethod == "database")
            {
                ClsDbDataLayer objDbDataLayer = new ClsDbDataLayer();
                if (objDbDataLayer.GetRecordDataFromDB(vlo))
                {
                    return true;
                }
            }
            else
            {
                OpenFlatFile(vlo);
            }
            return false;
        }

        private void OpenFlatFile(ValueLayerObject vlo)
        {
            string filePath = Environment.CurrentDirectory + "\\InputDataFile.is";
            if (File.Exists(filePath))
            {
                using (InputDataFile = File.Open(filePath, FileMode.Open, FileAccess.Read))
                {
                    using (BinaryReader reader = new BinaryReader(InputDataFile, Encoding.UTF8, true))
                    {
                        // Convert bytes to string using UTF-8 encoding
                        while (InputDataFile.Position + 927 < InputDataFile.Length)
                        {
                            string data = ReadData(reader);
                            vlo.records.Add(data);
                        }
                    }
                    InputDataFile.Close();
                }
                InputDataFile = File.Open(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            }
            else
            {
                InputDataFile = File.Open(filePath, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None);
            }
        }

        /// <summary>
        /// Close the Opened File, And release All the locks on the file
        /// </summary>
        public void CloseFile(ValueLayerObject vlo)
        {
            if (!(vlo.dataStorageMethod == "database"))
            {
                CloseFlatFile();

            }
            vlo.records = null;
        }

        private void CloseFlatFile()
        {
            InputDataFile.Dispose();
            InputDataFile.Close();
        }

        /// <summary>
        /// Store the Record in the File. 
        /// Insert, Update And Deletion of records is Done here.
        /// </summary>
        /// <param name="vo"></param>
        /// <param name="vlo"></param>
        /// <returns></returns>
        public bool FinalSave(clsEmployeeVO vo, ValueLayerObject vlo)
        {
            if (vlo.dataStorageMethod == "database")
            {
                ClsDbDataLayer objDbDataLayer = new ClsDbDataLayer();

                return objDbDataLayer.StoreToDatabase(vo, vlo);
            }
            else
            {
                return StoreToFlatFile(vo, vlo);
            }
        }

        private bool StoreToFlatFile(clsEmployeeVO vo, ValueLayerObject vlo)
        {
            try
            {
                if (InputDataFile.CanWrite)
                {
                    if (vo.dataToStore.Length == 927 && vo.editMode == EditMode.Create)
                    {

                        Insert(vo.dataToStore, vlo);
                    }
                    else
                    {
                        Update(vlo);
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                vo.userDefineError = ex.ToString();
                return false;
            }
        }

        private bool Insert(string data, ValueLayerObject vlo)
        {
            InputDataFile.Position = InputDataFile.Length;
            using (BinaryWriter writer = new BinaryWriter(InputDataFile, Encoding.UTF8, true))
            {
                EmployeeData record = new EmployeeData();
                vlo.AssigndataToEMployeeData(record, data);
                StoreData(writer, record);
                return true;
            }
        }

        private bool Update(ValueLayerObject vlo)
        {
            InputDataFile.SetLength(0);
            InputDataFile.Position = 0;
            using (BinaryWriter writer = new BinaryWriter(InputDataFile, Encoding.UTF8, true))
            {
                foreach (string currentrecordstring in vlo.records)
                {
                    EmployeeData record = new EmployeeData();
                    vlo.AssigndataToEMployeeData(record, currentrecordstring);
                    StoreData(writer, record);
                }
                return true;
            }
        }

        
        private string ReadData(BinaryReader reader)
        {
            StringBuilder dataBuilder = new StringBuilder();

            // Read each property from the binary file and pad strings as needed
            long SerialNumber = reader.ReadInt64();
            dataBuilder.Append(SerialNumber.ToString().PadRight(18));

            string Prefix = Encoding.UTF8.GetString(reader.ReadBytes(7)).TrimEnd();
            dataBuilder.Append(Prefix.PadRight(7));

            string FirstName = Encoding.UTF8.GetString(reader.ReadBytes(50)).TrimEnd();
            dataBuilder.Append(FirstName.PadRight(50));

            string MiddleName = Encoding.UTF8.GetString(reader.ReadBytes(25)).TrimEnd();
            dataBuilder.Append(MiddleName.PadRight(25));

            string LastName = Encoding.UTF8.GetString(reader.ReadBytes(50)).TrimEnd();
            dataBuilder.Append(LastName.PadRight(50));

            DateTime DateOfBirth = new DateTime(reader.ReadInt64());
            dataBuilder.Append(DateOfBirth.ToString("MM/dd/yyyy").PadRight(10));

            Byte Qualification = reader.ReadByte();
            dataBuilder.Append(Qualification.ToString().PadRight(2));

            string CurrentCompany = Encoding.UTF8.GetString(reader.ReadBytes(255)).TrimEnd();
            dataBuilder.Append(CurrentCompany.PadRight(255));

            DateTime JoiningDate = new DateTime(reader.ReadInt64());
            dataBuilder.Append(JoiningDate.ToString("MM/dd/yyyy").PadRight(10));

            string CurrentAddress = Encoding.UTF8.GetString(reader.ReadBytes(500)).TrimEnd();
            dataBuilder.Append(CurrentAddress.PadRight(500));

            return dataBuilder.ToString();

        }

       
        private void StoreData(BinaryWriter writer, EmployeeData record)
        {
            // Write each property to the binary file
            writer.Write(record.SerialNumber);
            writer.Write(Encoding.UTF8.GetBytes(record.Prefix.PadRight(7))); // Convert string to bytes and ensure fixed size
            writer.Write(Encoding.UTF8.GetBytes(record.FirstName.PadRight(50))); // Convert string to bytes and ensure fixed size
            writer.Write(Encoding.UTF8.GetBytes(record.MiddleName.PadRight(25))); // Convert string to bytes and ensure fixed size
            writer.Write(Encoding.UTF8.GetBytes(record.LastName.PadRight(50))); // Convert string to bytes and ensure fixed size
            writer.Write(record.DateOfBirth.Ticks); // Write ticks representing the DateTime value
            writer.Write(record.Qualification);
            writer.Write(Encoding.UTF8.GetBytes(record.CurrentCompany.PadRight(255))); // Convert string to bytes and ensure fixed size
            writer.Write(record.JoiningDate.Ticks); // Write ticks representing the DateTime value
            writer.Write(Encoding.UTF8.GetBytes(record.CurrentAddress.PadRight(500))); // Convert string to bytes and ensure fixed size
        }
    }


}