﻿using FIleHandlingSystem.VO;

namespace FileHandlingSystem.DL
{
    public interface IClsAuthenticator
    {
        bool Authenticate(AuthenticatorValueObject vo, ValueLayerObject vlo);
    }
}