﻿using FIleHandlingSystem.VO;

namespace FileHandlingSystem.DL
{
    public interface IclsConfiguration
    {
        bool GetConfig(ValueLayerObject vlo);
    }
}