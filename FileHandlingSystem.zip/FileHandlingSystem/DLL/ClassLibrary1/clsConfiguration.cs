﻿using System.IO;
using System.Security.Cryptography;
using System;
using FIleHandlingSystem.VO;
using FileHandlingSystem.Resources;

namespace FileHandlingSystem.DL
{
    public partial class clsConfiguration : IclsConfiguration
    {
        /// <summary>
        /// get Configuration data
        /// </summary>
        /// <param name="vlo"></param>
        /// <returns></returns>
        public bool GetConfig(ValueLayerObject vlo)
        {
            string configFilePath = Environment.CurrentDirectory + "\\FHS.vispl";
            // string configFilePath = "C:\\VISPL\\FileHandlingSystem\\bin\\Debug\\FHP.config";
            if (File.Exists(configFilePath))
            {
                GetConfigData(configFilePath, vlo);
                return true;
            }
            return false;
        }

        private bool GetConfigData(string filePath, ValueLayerObject vlo)
        {
            try
            {
                using (MemoryStream fs = new MemoryStream())
                {
                    DecryptFiles(fs, filePath);
                    using (BinaryReader reader = new BinaryReader(fs))
                    {
                        while (reader.PeekChar() != -1)
                        {
                            string filetype = reader.ReadString();
                            string UIType = reader.ReadString();
                            string server = reader.ReadString();
                            string database = reader.ReadString();
                            bool integratedsecurity = reader.ReadBoolean();

                            vlo.dataStorageMethod = filetype;
                            vlo.UIType = UIType;
                            vlo.connectionString = String.Format($"Server={server};Database={database};Integrated Security={integratedsecurity.ToString()};");
                        }
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void DecryptFiles(MemoryStream outputStream, string filePath)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = GetEncryptionCode();

                byte[] iv = new byte[aes.IV.Length];
                using (Stream resourceStream = File.OpenRead(filePath))
                {
                    // Read IV from the beginning of the encrypted file
                    resourceStream.Read(iv, 0, iv.Length);

                    // Set IV for decryption
                    aes.IV = iv;

                    using (CryptoStream cryptoStream = new CryptoStream(resourceStream, aes.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        outputStream.Position = 0;

                        // Decrypt the file content
                        cryptoStream.CopyTo(outputStream);

                        // Reset position of the outputStream after decryption
                        outputStream.Position = 0;
                    }
                }
            }
        }
    }
}