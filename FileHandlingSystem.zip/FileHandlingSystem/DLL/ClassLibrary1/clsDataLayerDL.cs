﻿using System;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;

namespace FileHandlingSystem.DL
{
    public partial class ClsAuthenticator : IClsAuthenticator
    {
        /// <summary>
        /// FUnction to Get Byte value of encryption key
        /// </summary>
        /// <returns>Byte Value of key</returns>
        private byte[] GetEncryptionCode()
        {
            string keys = "IshikaSrivastava";
            string concatenatedKey = keys + "Vertexdevelopment";

            // Create a hash of the concatenated key to ensure a valid key size
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(concatenatedKey));
                return hashBytes;
            }
        }



        private Stream GetEmbeddedResourceStream(string resourceName)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            return assembly.GetManifestResourceStream(resourceName);
        }
    }

    /// <summary>
    /// Partial class to contain method of configurations
    /// </summary>
    public partial class clsConfiguration
    {
        private byte[] GetEncryptionCode()
        {
            string keys = "FileHandlingSystem";
            // Generate a random encryption key
            return Convert.FromBase64String(keys + "CreateByVertex");
        }
    }
}