﻿using FileHandlingSystem.Resources;
using System.Data.SqlClient;
using System;
using System.IO;
using System.Security.Cryptography;
using FIleHandlingSystem.VO;


namespace FileHandlingSystem.DL
{
    /// <summary>
    /// class to contain members to authenticate the ser
    /// </summary>
    public partial class ClsAuthenticator
    {
        /// <summary>
        /// Authenticate theuser with current user credentials
        /// </summary>
        /// <param name="vo"></param>
        /// <param name="vlo"></param>
        /// <returns></returns>
        public bool Authenticate(AuthenticatorValueObject vo, ValueLayerObject vlo)
        {
            if (vlo.dataStorageMethod == "database")
            {
                ClsDBAuthenticationDataLayer objauthenticator = new ClsDBAuthenticationDataLayer();
                if (objauthenticator.Authenticate(vo, vlo))
                {
                    return true;
                }
            }
            else
            {
                if (CheckUsers(vo))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Authenticate the user based on his user type and his credentials
        /// </summary>
        /// <param name="vo"></param>
        /// <returns></returns>
        private bool CheckUsers(AuthenticatorValueObject vo)
        {
            const string resourcename = "DL_FileHandlingSystem.users.ini";
            bool validUser = false;

            using (MemoryStream fs = new MemoryStream())
            {
                DecryptFile(resourcename, fs);
                using (BinaryReader reader = new BinaryReader(fs))
                {
                    while (reader.PeekChar() != -1)
                    {
                        byte usertype = reader.ReadByte();
                        if (vo.userType == (UserTypes)usertype)
                        {
                            string username = reader.ReadString();
                            string password = reader.ReadString();

                            if (vo.username.ToLower() == username.ToLower() && vo.password == password)
                            {
                                validUser = true;
                                break;
                            }
                        }
                        else
                        {
                            reader.ReadString();
                            reader.ReadString();
                        }
                    }
                }
            }
            return validUser;
        }

        /// <summary>
        ///  Decrypt the Embedded resource stream into Output Stream
        /// </summary>
        /// <param name="resourceName">Resource stream path</param>
        /// <param name="outputStream">Object of memory stream class to store the decrypted resource</param>
        private void DecryptFile(string resourceName, MemoryStream outputStream)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = GetEncryptionCode();

                byte[] iv = new byte[aes.IV.Length];
                using (Stream resourceStream = GetEmbeddedResourceStream(resourceName))
                {
                    // Read IV from the beginning of the encrypted file
                    resourceStream.Read(iv, 0, iv.Length);

                    // Set IV for decryption
                    aes.IV = iv;

                    using (CryptoStream cryptoStream = new CryptoStream(resourceStream, aes.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        outputStream.Position = 0;

                        // Decrypt the file content
                        cryptoStream.CopyTo(outputStream);

                        // Reset position of the outputStream after decryption
                        outputStream.Position = 0;
                    }
                }
            }
        }
    }


    /// <summary>
    /// Class to Authenticate the user
    /// </summary>
    public class ClsDBAuthenticationDataLayer
    {

        /// <summary>
        /// Function to Fetch Records from dataBase
        /// </summary>
        /// <param name="vo"></param>
        /// <returns></returns>
        public bool Authenticate(AuthenticatorValueObject vo, ValueLayerObject vlo)
        {
            try
            {
                // Connect to the SQL Server database and retrieve data from the UserData table
                using (SqlConnection connection = new SqlConnection(vlo.connectionString))
                {
                    string sqlQuery = "SELECT * FROM Credentails";

                    SqlCommand command = new SqlCommand(sqlQuery, connection);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    bool validUser = false;
                    // Read data from the database and populate UserData objects
                    while (reader.Read())
                    {

                        if (reader.HasRows)
                        {
                            byte user = (Byte)reader[2];
                            if (((UserTypes)(user - 1)) == vo.userType)
                            {
                                string username = reader[0].ToString();
                                string password = reader[1].ToString();
                                if (vo.username.ToLower() == username.ToLower() && password == vo.password)
                                {
                                    validUser = true;
                                    break;
                                }
                            }
                        }

                    }

                    reader.Close();
                    connection.Dispose();
                    connection.Close();
                    return validUser;
                }
            }
            catch (Exception ex)
            {
                throw ex;
                return false;
            }
        }

    }
}