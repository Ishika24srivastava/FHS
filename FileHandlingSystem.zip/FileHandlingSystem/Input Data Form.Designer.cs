﻿namespace FileHandlingSystem
{
    partial class InputDataForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InputDataForm));
            this.label1 = new System.Windows.Forms.Label();
            this.textbox_serialNumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textbox_firstname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textbox_middlename = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textbox_lastname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textbox_currentcompany = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textbox_currentaddress = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dtp_dateofBirth = new System.Windows.Forms.DateTimePicker();
            this.dtp_joiningDate = new System.Windows.Forms.DateTimePicker();
            this.first_Btn = new System.Windows.Forms.Button();
            this.previous_Btn = new System.Windows.Forms.Button();
            this.next_Btn = new System.Windows.Forms.Button();
            this.last_Btn = new System.Windows.Forms.Button();
            this.add_Btn = new System.Windows.Forms.Button();
            this.clear_Btn = new System.Windows.Forms.Button();
            this.edit_Btn = new System.Windows.Forms.Button();
            this.cb_prefix = new System.Windows.Forms.ComboBox();
            this.cb_qualification = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Serial Number*";
            // 
            // textbox_serialNumber
            // 
            this.textbox_serialNumber.Location = new System.Drawing.Point(116, 18);
            this.textbox_serialNumber.Margin = new System.Windows.Forms.Padding(2);
            this.textbox_serialNumber.MaxLength = 18;
            this.textbox_serialNumber.Multiline = true;
            this.textbox_serialNumber.Name = "textbox_serialNumber";
            this.textbox_serialNumber.Size = new System.Drawing.Size(94, 19);
            this.textbox_serialNumber.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 48);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Prefix";
            // 
            // textbox_firstname
            // 
            this.textbox_firstname.Location = new System.Drawing.Point(116, 79);
            this.textbox_firstname.Margin = new System.Windows.Forms.Padding(2);
            this.textbox_firstname.MaxLength = 50;
            this.textbox_firstname.Name = "textbox_firstname";
            this.textbox_firstname.Size = new System.Drawing.Size(92, 20);
            this.textbox_firstname.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 82);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "First Name*";
            // 
            // textbox_middlename
            // 
            this.textbox_middlename.Location = new System.Drawing.Point(116, 111);
            this.textbox_middlename.Margin = new System.Windows.Forms.Padding(2);
            this.textbox_middlename.MaxLength = 25;
            this.textbox_middlename.Name = "textbox_middlename";
            this.textbox_middlename.Size = new System.Drawing.Size(94, 20);
            this.textbox_middlename.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 118);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Middle Name";
            // 
            // textbox_lastname
            // 
            this.textbox_lastname.Location = new System.Drawing.Point(116, 145);
            this.textbox_lastname.Margin = new System.Windows.Forms.Padding(2);
            this.textbox_lastname.MaxLength = 50;
            this.textbox_lastname.Name = "textbox_lastname";
            this.textbox_lastname.Size = new System.Drawing.Size(94, 20);
            this.textbox_lastname.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 152);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Last Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 183);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Date of Birth";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 222);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Qualification*";
            // 
            // textbox_currentcompany
            // 
            this.textbox_currentcompany.Location = new System.Drawing.Point(116, 316);
            this.textbox_currentcompany.Margin = new System.Windows.Forms.Padding(2);
            this.textbox_currentcompany.MaxLength = 255;
            this.textbox_currentcompany.Multiline = true;
            this.textbox_currentcompany.Name = "textbox_currentcompany";
            this.textbox_currentcompany.Size = new System.Drawing.Size(200, 21);
            this.textbox_currentcompany.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 319);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Current Company*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 350);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Joining Date*";
            // 
            // textbox_currentaddress
            // 
            this.textbox_currentaddress.Location = new System.Drawing.Point(116, 262);
            this.textbox_currentaddress.Margin = new System.Windows.Forms.Padding(2);
            this.textbox_currentaddress.MaxLength = 500;
            this.textbox_currentaddress.Multiline = true;
            this.textbox_currentaddress.Name = "textbox_currentaddress";
            this.textbox_currentaddress.Size = new System.Drawing.Size(374, 39);
            this.textbox_currentaddress.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 262);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Current Address";
            // 
            // dtp_dateofBirth
            // 
            this.dtp_dateofBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_dateofBirth.Location = new System.Drawing.Point(116, 183);
            this.dtp_dateofBirth.Margin = new System.Windows.Forms.Padding(2);
            this.dtp_dateofBirth.MaxDate = new System.DateTime(2999, 12, 31, 0, 0, 0, 0);
            this.dtp_dateofBirth.MinDate = new System.DateTime(1799, 12, 2, 0, 0, 0, 0);
            this.dtp_dateofBirth.Name = "dtp_dateofBirth";
            this.dtp_dateofBirth.Size = new System.Drawing.Size(94, 20);
            this.dtp_dateofBirth.TabIndex = 21;
            this.dtp_dateofBirth.ValueChanged += new System.EventHandler(this.dtp_dateofBirth_ValueChanged);
            // 
            // dtp_joiningDate
            // 
            this.dtp_joiningDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_joiningDate.Location = new System.Drawing.Point(116, 350);
            this.dtp_joiningDate.Margin = new System.Windows.Forms.Padding(2);
            this.dtp_joiningDate.MaxDate = new System.DateTime(2999, 12, 31, 0, 0, 0, 0);
            this.dtp_joiningDate.MinDate = new System.DateTime(1799, 1, 1, 0, 0, 0, 0);
            this.dtp_joiningDate.Name = "dtp_joiningDate";
            this.dtp_joiningDate.Size = new System.Drawing.Size(94, 20);
            this.dtp_joiningDate.TabIndex = 22;
            this.dtp_joiningDate.ValueChanged += new System.EventHandler(this.dtp_joiningDate_ValueChanged);
            // 
            // first_Btn
            // 
            this.first_Btn.Location = new System.Drawing.Point(43, 406);
            this.first_Btn.Margin = new System.Windows.Forms.Padding(2);
            this.first_Btn.Name = "first_Btn";
            this.first_Btn.Size = new System.Drawing.Size(80, 26);
            this.first_Btn.TabIndex = 23;
            this.first_Btn.Text = "First";
            this.first_Btn.UseVisualStyleBackColor = true;
            this.first_Btn.Click += new System.EventHandler(this.firstBtn_Click);
            // 
            // previous_Btn
            // 
            this.previous_Btn.Location = new System.Drawing.Point(148, 406);
            this.previous_Btn.Margin = new System.Windows.Forms.Padding(2);
            this.previous_Btn.Name = "previous_Btn";
            this.previous_Btn.Size = new System.Drawing.Size(77, 26);
            this.previous_Btn.TabIndex = 24;
            this.previous_Btn.Text = "Previous";
            this.previous_Btn.UseVisualStyleBackColor = true;
            this.previous_Btn.Click += new System.EventHandler(this.previousBtn_Click);
            // 
            // next_Btn
            // 
            this.next_Btn.Location = new System.Drawing.Point(266, 404);
            this.next_Btn.Margin = new System.Windows.Forms.Padding(2);
            this.next_Btn.Name = "next_Btn";
            this.next_Btn.Size = new System.Drawing.Size(80, 28);
            this.next_Btn.TabIndex = 25;
            this.next_Btn.Text = "Next";
            this.next_Btn.UseVisualStyleBackColor = true;
            this.next_Btn.Click += new System.EventHandler(this.nextBtn_Click);
            // 
            // last_Btn
            // 
            this.last_Btn.Location = new System.Drawing.Point(371, 402);
            this.last_Btn.Margin = new System.Windows.Forms.Padding(2);
            this.last_Btn.Name = "last_Btn";
            this.last_Btn.Size = new System.Drawing.Size(84, 30);
            this.last_Btn.TabIndex = 26;
            this.last_Btn.Text = "Last";
            this.last_Btn.UseVisualStyleBackColor = true;
            this.last_Btn.Click += new System.EventHandler(this.lastBtn_Click);
            // 
            // add_Btn
            // 
            this.add_Btn.Location = new System.Drawing.Point(69, 452);
            this.add_Btn.Margin = new System.Windows.Forms.Padding(2);
            this.add_Btn.Name = "add_Btn";
            this.add_Btn.Size = new System.Drawing.Size(91, 32);
            this.add_Btn.TabIndex = 27;
            this.add_Btn.Text = "Add";
            this.add_Btn.UseVisualStyleBackColor = true;
            this.add_Btn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // clear_Btn
            // 
            this.clear_Btn.Location = new System.Drawing.Point(184, 452);
            this.clear_Btn.Margin = new System.Windows.Forms.Padding(2);
            this.clear_Btn.Name = "clear_Btn";
            this.clear_Btn.Size = new System.Drawing.Size(88, 34);
            this.clear_Btn.TabIndex = 28;
            this.clear_Btn.Text = "Clear";
            this.clear_Btn.UseVisualStyleBackColor = true;
            this.clear_Btn.Click += new System.EventHandler(this.clearBtnClick);
            // 
            // edit_Btn
            // 
            this.edit_Btn.Location = new System.Drawing.Point(305, 452);
            this.edit_Btn.Margin = new System.Windows.Forms.Padding(2);
            this.edit_Btn.Name = "edit_Btn";
            this.edit_Btn.Size = new System.Drawing.Size(93, 32);
            this.edit_Btn.TabIndex = 29;
            this.edit_Btn.Text = "Edit";
            this.edit_Btn.UseVisualStyleBackColor = true;
            this.edit_Btn.Click += new System.EventHandler(this.editBtnClick);
            // 
            // cb_prefix
            // 
            this.cb_prefix.FormattingEnabled = true;
            this.cb_prefix.Items.AddRange(new object[] {
            "Mr.",
            "Mrs.",
            "Miss."});
            this.cb_prefix.Location = new System.Drawing.Point(116, 48);
            this.cb_prefix.Margin = new System.Windows.Forms.Padding(2);
            this.cb_prefix.Name = "cb_prefix";
            this.cb_prefix.Size = new System.Drawing.Size(92, 21);
            this.cb_prefix.TabIndex = 30;
            // 
            // cb_qualification
            // 
            this.cb_qualification.FormattingEnabled = true;
            this.cb_qualification.Location = new System.Drawing.Point(116, 222);
            this.cb_qualification.Margin = new System.Windows.Forms.Padding(2);
            this.cb_qualification.Name = "cb_qualification";
            this.cb_qualification.Size = new System.Drawing.Size(145, 21);
            this.cb_qualification.TabIndex = 31;
            // 
            // InputDataForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(518, 517);
            this.Controls.Add(this.cb_qualification);
            this.Controls.Add(this.cb_prefix);
            this.Controls.Add(this.edit_Btn);
            this.Controls.Add(this.clear_Btn);
            this.Controls.Add(this.add_Btn);
            this.Controls.Add(this.last_Btn);
            this.Controls.Add(this.next_Btn);
            this.Controls.Add(this.previous_Btn);
            this.Controls.Add(this.first_Btn);
            this.Controls.Add(this.dtp_joiningDate);
            this.Controls.Add(this.dtp_dateofBirth);
            this.Controls.Add(this.textbox_currentaddress);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textbox_currentcompany);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textbox_lastname);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textbox_middlename);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textbox_firstname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textbox_serialNumber);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximumSize = new System.Drawing.Size(538, 560);
            this.MinimumSize = new System.Drawing.Size(538, 560);
            this.Name = "InputDataForm";
            this.Text = "Input Data Form";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UserForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.UserForm_FormClosed);
            this.Load += new System.EventHandler(this.UserForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textbox_serialNumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textbox_firstname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textbox_middlename;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textbox_lastname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textbox_currentcompany;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textbox_currentaddress;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtp_joiningDate;
        private System.Windows.Forms.Button first_Btn;
        private System.Windows.Forms.Button previous_Btn;
        private System.Windows.Forms.Button next_Btn;
        private System.Windows.Forms.Button last_Btn;
        private System.Windows.Forms.Button add_Btn;
        private System.Windows.Forms.Button clear_Btn;
        private System.Windows.Forms.Button edit_Btn;
        private System.Windows.Forms.ComboBox cb_prefix;
        private System.Windows.Forms.ComboBox cb_qualification;
        private System.Windows.Forms.DateTimePicker dtp_dateofBirth;
    }
}