﻿using System;
using System.Windows.Forms;
using FIleHandlingSystem.VO;
using FileHandlingSystem.BL;
using FileHandlingSystem.Resources;

namespace FileHandlingSystem
{
    /// <summary>
    /// Partial class for user form class
    /// </summary>
    public partial class InputDataForm : Form
    {
        private long serialNum;
        private string operationperformed;
        private clsResoucresModuleResources rsc;
        private ValueLayerObject vlo;

        /// <summary>
        /// Constructor function, whcih will be invoked when and object of thsi class is created
        /// </summary>
        /// <param name="vlo">Object of Value layer object classs</param>
        public InputDataForm(ValueLayerObject vlo)
        {
            InitializeComponent();

            foreach (Qualification day in Enum.GetValues(typeof(Qualification)))
            {
                cb_qualification.Items.Add(day);
            }

            this.vlo = vlo;
            textbox_serialNumber.Enabled = false;
            operationperformed = "";
            rsc = new clsResoucresModuleResources();
        }

        private void UserForm_Load(object sender, EventArgs e)
        {
            InitializeElement();
        }

        /// <summary>
        /// Initialize the Element of form
        /// </summary>
        private void InitializeElement()
        {
            dtp_dateofBirth.Checked = false;
            dtp_joiningDate.Checked = false;

            Cleardata();
            if (vlo.UserFormType == "New")
            {
                DisableScrollButtons();
                dtp_dateofBirth.CustomFormat = " ";
                dtp_joiningDate.CustomFormat = " ";
                dtp_joiningDate.Format = DateTimePickerFormat.Custom;
                dtp_dateofBirth.Format = DateTimePickerFormat.Custom;
                edit_Btn.Enabled = false;
                textbox_serialNumber.Text = vlo.serialNumber.ToString();
            }
            else if (vlo.UserFormType == "Update")
            {
                DisableScrollButtons();
                add_Btn.Enabled = false;
                serialNum = FindRowWithSerialNumber(Convert.ToInt64(vlo.values[0]?.ToString()));
                InsertDataInViewForm(serialNum);
            }
            else if (vlo.UserFormType == "View")
            {
                add_Btn.Visible = false;
                clear_Btn.Visible = false;
                edit_Btn.Visible = false;
                serialNum = FindRowWithSerialNumber(Convert.ToInt64(vlo.values[0]?.ToString()));
                EnableButtonOfView(serialNum);
                InsertDataInViewForm(serialNum);
                OpenFormInReadOnly();
            }
        }

        /// <summary>
        /// Open the form in readonly mode, so that no new changes can be done
        /// </summary>
        private void OpenFormInReadOnly()
        {
            cb_prefix.Enabled = false;
            textbox_firstname.Enabled = false;
            textbox_lastname.Enabled = false;
            textbox_middlename.Enabled = false;
            cb_qualification.Enabled = false;
            textbox_currentcompany.Enabled = false;
            textbox_currentaddress.Enabled = false;
            dtp_dateofBirth.Enabled = false;
            dtp_joiningDate.Enabled = false;
        }

        /// <summary>
        /// Insert the data into user form
        /// </summary>
        /// <param name="index"></param>
        private void InsertDataInViewForm(long index)
        {
            textbox_serialNumber.Text = vlo.userData[index, 0];
            cb_prefix.Text = vlo.userData[index, 1];
            textbox_firstname.Text = vlo.userData[index, 2];
            textbox_middlename.Text = vlo.userData[index, 3];
            textbox_lastname.Text = vlo.userData[index, 4];
            cb_qualification.Text = vlo.userData[index, 6];
            textbox_currentcompany.Text = vlo.userData[index, 7];
            textbox_currentaddress.Text = vlo.userData[index, 9];

            if (DateTime.TryParse(vlo.userData[index, 5], out DateTime dateOfBirth))
            {
                if (dateOfBirth == DateTime.Parse("01/01/1800"))
                {
                    dtp_dateofBirth.CustomFormat = " ";
                    dtp_dateofBirth.Format = DateTimePickerFormat.Custom;
                }
                else
                {
                    dtp_dateofBirth.Checked = true;
                    dtp_dateofBirth.Format = DateTimePickerFormat.Custom;
                    dtp_dateofBirth.Value = dateOfBirth;
                    dtp_dateofBirth.CustomFormat = dateOfBirth.ToString("MM/dd/yyyy");
                }
            }
            else
            {
                dtp_dateofBirth.Visible = false;
            }

            if (DateTime.TryParse(vlo.userData[index, 8], out DateTime joiningDate))
            {
                if (joiningDate == DateTime.Parse("01/01/1800"))
                {
                    dtp_joiningDate.CustomFormat = " ";
                    dtp_joiningDate.Format = DateTimePickerFormat.Custom;
                }
                else
                {
                    dtp_joiningDate.Checked = true;
                    dtp_joiningDate.Format = DateTimePickerFormat.Custom;
                    dtp_joiningDate.Value = joiningDate;
                    dtp_joiningDate.CustomFormat = joiningDate.ToString("MM/dd/yyyy");
                }
            }
            else
            {
                dtp_joiningDate.Visible = false;
            }
        }

        /// <summary>
        /// Disable the button used for view only form
        /// </summary>
        private void DisableScrollButtons()
        {
            first_Btn.Visible = false;
            last_Btn.Visible = false;
            previous_Btn.Visible = false;
            next_Btn.Visible = false;
        }

        /// <summary>
        /// Enable all the elements, so that when form is opened gain, no element is disable dby default
        /// </summary>
        private void EnableElements()
        {
            first_Btn.Visible = true;
            last_Btn.Visible = true;
            previous_Btn.Visible = true;
            next_Btn.Visible = true;
            add_Btn.Visible = true;
            edit_Btn.Visible = true;
            clear_Btn.Visible = true;
            add_Btn.Enabled = true;
            edit_Btn.Enabled = true;

            cb_prefix.Enabled = true;
            textbox_firstname.Enabled = true;
            textbox_lastname.Enabled = true;
            textbox_middlename.Enabled = true;
            cb_qualification.Enabled = true;
            textbox_currentcompany.Enabled = true;
            textbox_currentaddress.Enabled = true;
            dtp_dateofBirth.Enabled = true;
            dtp_joiningDate.Enabled = true;
        }

        /// <summary>
        /// Pad the Input Data from the user into the format, whcih is requiree to store the record
        /// </summary>
        /// <returns>Padded record in string</returns>
        private string GetPaddedInputdata()
        {
            string data = "";
            data += PadString(textbox_serialNumber.Text, 18);
            data += PadString(cb_prefix.Text, 7);
            data += PadString(textbox_firstname.Text, 50);
            data += PadString(textbox_middlename.Text, 25);
            data += PadString(textbox_lastname.Text, 50);
            if (dtp_dateofBirth.Checked)
            {
                data += PadString(dtp_dateofBirth.Value.ToString(), 10);
            }
            else
            {
                data += PadString("01/01/1800", 10);
            }

            if (Enum.IsDefined(typeof(Qualification), cb_qualification.Text))
            {
                Qualification qualification = (Qualification)Enum.Parse(typeof(Qualification), cb_qualification.Text);
                int enumIndex = (int)qualification;
                data += PadString(enumIndex.ToString(), 2);
            }
            else
            {
                data += PadString("0", 2);
            }
            data += PadString(textbox_currentcompany.Text, 255);

            if (dtp_joiningDate.Checked)
            {
                data += PadString(dtp_joiningDate.Value.ToString(), 10);
            }
            else
            {
                data += PadString("01/01/1800", 10);
            }

            data += PadString(textbox_currentaddress.Text, 500);

            return data;
        }

              /// <summary>
        /// Function to focus on element of form where the invalid data is present
        /// </summary>
        /// <param name="vo">Object of Value object class</param>
        private void FocusOnInvalidBox(clsEmployeeVO vo)
        {
            if (vo.error == ErrorMessage.firstnameEmpty)
            {
                textbox_firstname.Focus();
            }
            else if (vo.error == ErrorMessage.qualificationEmpty || vo.error == ErrorMessage.qualificationdowngrade)
            {
                cb_qualification.Focus();
            }
            else if (vo.error == ErrorMessage.emptyJoiningDate)
            {
                dtp_joiningDate.Focus();
            }
            else if (vo.error == ErrorMessage.currentCompanyEmpty)
            {
                textbox_currentcompany.Focus();
            }
            else if (vo.error == ErrorMessage.errordateOfBirthGreaterThanjoiningdate)
            {
                dtp_dateofBirth.Focus();
            }
        }

        /// <summary>
        /// pad single string with Space character
        /// </summary>
        /// <param name="input"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public string PadString(string input, int length)
        {
            if (input.Length >= length)
            {
                return input.Substring(0, length);
            }
            else
            {
                return input.PadRight(length);
            }
        }

        /// <summary>
        /// Check changes made after the form is opened
        /// </summary>
        /// <returns></returns>
        private bool checkChange()
        {
            if (vlo.UserFormType == "Update")
            {
                if (cb_prefix.Text != vlo.values[1]?.ToString() || textbox_firstname.Text != vlo.values[2]?.ToString() || textbox_middlename.Text != vlo.values[3]?.ToString()
                    || textbox_lastname.Text != vlo.values[4]?.ToString() || cb_qualification.Text != vlo.values[6]?.ToString() || textbox_currentcompany.Text != vlo.values[7]?.ToString()
                    || textbox_currentaddress.Text != vlo.values[9]?.ToString())
                {
                    return true;
                }
                else if (dtp_dateofBirth.Value != Convert.ToDateTime(vlo.values[5]) || dtp_joiningDate.Value != Convert.ToDateTime(vlo.values[8]))
                {
                    if (dtp_dateofBirth.Text != " ")
                    {
                        return true;
                    }
                }
            }
            else if (vlo.UserFormType == "New")
            {
                if (cb_prefix.Text != "" || textbox_firstname.Text != "" || textbox_middlename.Text != ""
                    || textbox_lastname.Text != "" || cb_qualification.Text != "" || textbox_currentcompany.Text != ""
                    || textbox_currentaddress.Text != "")
                {
                    return true;
                }
                else if (dtp_dateofBirth.Text != " " || dtp_joiningDate.Text != " ")
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Edit the Record data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
    
        /// <summary>
        /// function to change record from update record from new record
        /// </summary>
        private void ClearInEditMode()
        {
            if (vlo.UserFormType == "Update")
            {
                vlo.UserFormType = "New";
                textbox_serialNumber.Text = vlo.serialNumber.ToString();
                add_Btn.Enabled = true;
                edit_Btn.Enabled = false;
            }
        }

        /// <summary>
        /// clear the form when clear button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_clear_Click(object sender, EventArgs e)
        {
            
        }

        /// <summary>
        /// Clear all the form inputs  to default value
        /// </summary>
        private void Cleardata()
        {
            cb_prefix.Text = "";
            textbox_firstname.Text = "";
            textbox_lastname.Text = "";
            textbox_middlename.Text = "";
            cb_qualification.Text = "";
            textbox_currentcompany.Text = "";
            textbox_currentaddress.Text = "";
            cb_prefix.SelectedIndex = -1;
            cb_qualification.SelectedIndex = -1;

            dtp_dateofBirth.Checked = false;
            dtp_joiningDate.Checked = false;
            dtp_dateofBirth.CustomFormat = " ";
            dtp_joiningDate.CustomFormat = " ";
            dtp_joiningDate.Format = DateTimePickerFormat.Custom;
            dtp_dateofBirth.Format = DateTimePickerFormat.Custom;
        }

        /// <summary>
        /// Find Row with sae serial number,if present return the index of row otherwise return the -1
        /// </summary>
        /// <param name="serial"></param>
        /// <returns></returns>
        private int FindRowWithSerialNumber(long serial)
        {
            for (int i = 0; i < vlo.userData.GetLength(0); i++)
            {
                if (vlo.userData[i, 0] == serial.ToString())
                {
                    return i;
                }
            }
            return -1;
        }

        /// <summary>
        /// Enable button of viewonly form after pressing any button in that form
        /// </summary>
        /// <param name="index"></param>
        private void EnableButtonOfView(long index)
        {
            Cleardata();
            if (index == 0)
            {
                previous_Btn.Enabled = false;
                first_Btn.Enabled = false;
                next_Btn.Enabled = true;
                last_Btn.Enabled = true;
            }
            else if (index == vlo.userData.GetLength(0) - 1)
            {
                next_Btn.Enabled = false;
                last_Btn.Enabled = false;
                previous_Btn.Enabled = true;
                first_Btn.Enabled = true;
            }
            else
            {
                previous_Btn.Enabled = true;
                first_Btn.Enabled = true;
                next_Btn.Enabled = true;
                last_Btn.Enabled = true;
            }
        }

   
        private void UserForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            EnableElements();
            Cleardata();
        }

        private void UserForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (operationperformed != "saved" && operationperformed != "updated")
            {
                if (checkChange())
                {
                    DialogResult wantToClear = MessageBox.Show(rsc.GetEnumDescription(Messages.clearForm), rsc.GetEnumDescription(MessageCaptions.clearForm), MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                    if (wantToClear != DialogResult.OK)
                    {
                        e.Cancel = true;
                    }
                }
            }
        }

        private void dtp_dateofBirth_ValueChanged(object sender, EventArgs e)
        {
            // Update DateTimePicker value when user selects a date
            dtp_dateofBirth.CustomFormat = "MM/dd/yyyy"; // Change format to display the selected date
            dtp_dateofBirth.Format = DateTimePickerFormat.Custom;

        }

        private void dtp_joiningDate_ValueChanged(object sender, EventArgs e)
        {
            dtp_joiningDate.CustomFormat = "MM/dd/yyyy"; // Change format to display the selected date
            dtp_joiningDate.Format = DateTimePickerFormat.Custom;
        }

        private void firstBtn_Click(object sender, EventArgs e)
        {
            serialNum = 0;
            EnableButtonOfView(serialNum);
            InsertDataInViewForm(serialNum);
        }

        private void previousBtn_Click(object sender, EventArgs e)
        {
            if (serialNum > 0)
            {
                serialNum--;
                EnableButtonOfView(serialNum);
                InsertDataInViewForm(serialNum);
            }

        }

        private void nextBtn_Click(object sender, EventArgs e)
        {

            if (serialNum < vlo.userData.GetLength(0) - 1)
            {
                serialNum++;
                EnableButtonOfView(serialNum);
                InsertDataInViewForm(serialNum);
            }
        }

        private void lastBtn_Click(object sender, EventArgs e)
        {
            serialNum = vlo.userData.GetLength(0) - 1;
            EnableButtonOfView(serialNum);
            InsertDataInViewForm(serialNum);

        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            string data = GetPaddedInputdata();
            clsEmployeeVO vo = new clsEmployeeVO(data);
            if (vlo.AssigndataToEMployeeData(vo.EmployeeData, data))
            {
                clsBusinessLogicBL bl = new clsBusinessLogicBL();
                vo.editMode = EditMode.Create;
                if (bl.Save(vo, vlo))
                {
                    operationperformed = "saved";
                    this.Close();
                }
                else
                {
                    MessageBox.Show(rsc.GetEnumDescription(vo.error), rsc.GetEnumDescription(vo.caption), MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FocusOnInvalidBox(vo);
                }
            }

        }

        private void clearBtnClick(object sender, EventArgs e)
        {
            if (!checkChange())
            {
                Cleardata();
                ClearInEditMode();
            }
            else
            {
                DialogResult wantToClear = MessageBox.Show(rsc.GetEnumDescription(Messages.clearForm), rsc.GetEnumDescription(MessageCaptions.clearForm), MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (wantToClear == DialogResult.OK)
                {
                    Cleardata();
                    ClearInEditMode();
                }
            }

        }

        private void editBtnClick(object sender, EventArgs e)
        {
            if (checkChange())
            {
                string dataUpdated = GetPaddedInputdata();

                clsEmployeeVO vo = new clsEmployeeVO(dataUpdated);
                if (vlo.AssigndataToEMployeeData(vo.EmployeeData, dataUpdated))
                {
                    clsBusinessLogicBL bl = new clsBusinessLogicBL();
                    vo.editMode = EditMode.Update;
                    if (bl.Save(vo, vlo))
                    {
                        operationperformed = "updated";
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show(rsc.GetEnumDescription(vo.error), rsc.GetEnumDescription(vo.caption), MessageBoxButtons.OK, MessageBoxIcon.Information);
                        FocusOnInvalidBox(vo);
                        return;
                    }
                }

            }
            operationperformed = "updated";
            this.Close();
        }
    }
}
