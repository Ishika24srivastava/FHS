﻿using System;

namespace FileHandlingSystem
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.userData_grid = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.new_Btn = new System.Windows.Forms.ToolStripMenuItem();
            this.update_Btn = new System.Windows.Forms.ToolStripMenuItem();
            this.delete_Btn = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutUs_Btn = new System.Windows.Forms.ToolStripMenuItem();
            this.clear_Btn = new System.Windows.Forms.ToolStripMenuItem();
            this.exit_Btn = new System.Windows.Forms.ToolStripMenuItem();
            this.search_Btn = new System.Windows.Forms.ToolStripMenuItem();
            this.textbox_search = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.userData_grid)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // userData_grid
            // 
            this.userData_grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.userData_grid.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.userData_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.userData_grid.Location = new System.Drawing.Point(30, 45);
            this.userData_grid.Margin = new System.Windows.Forms.Padding(2);
            this.userData_grid.Name = "userData_grid";
            this.userData_grid.RowHeadersWidth = 51;
            this.userData_grid.RowTemplate.Height = 24;
            this.userData_grid.Size = new System.Drawing.Size(564, 368);
            this.userData_grid.TabIndex = 3;
            this.userData_grid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.userData_gridCellClick);
            this.userData_grid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.userData_grid_CellContentClick);
            this.userData_grid.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.userData_gridCellDoubleClick);
            this.userData_grid.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.userData_gridCellValueChanged);
            this.userData_grid.Scroll += new System.Windows.Forms.ScrollEventHandler(this.grd_userData_Scroll);
            this.userData_grid.SortCompare += new System.Windows.Forms.DataGridViewSortCompareEventHandler(this.grd_userData_SortCompare);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.new_Btn,
            this.update_Btn,
            this.delete_Btn,
            this.aboutUs_Btn,
            this.clear_Btn,
            this.exit_Btn,
            this.search_Btn});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(657, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // new_Btn
            // 
            this.new_Btn.Name = "new_Btn";
            this.new_Btn.Size = new System.Drawing.Size(43, 20);
            this.new_Btn.Text = "New";
            this.new_Btn.Click += new System.EventHandler(this.newBtn_Click);
            this.new_Btn.EnabledChanged += new System.EventHandler(this.btn_new_EnabledChanged);
            // 
            // update_Btn
            // 
            this.update_Btn.Name = "update_Btn";
            this.update_Btn.Size = new System.Drawing.Size(57, 20);
            this.update_Btn.Text = "Update";
            this.update_Btn.Click += new System.EventHandler(this.updateBtn_Click);
            this.update_Btn.EnabledChanged += new System.EventHandler(this.btn_update_EnabledChanged);
            // 
            // delete_Btn
            // 
            this.delete_Btn.Name = "delete_Btn";
            this.delete_Btn.Size = new System.Drawing.Size(52, 20);
            this.delete_Btn.Text = "Delete";
            this.delete_Btn.Click += new System.EventHandler(this.deleteBtn_Click);
            this.delete_Btn.EnabledChanged += new System.EventHandler(this.btn_delete_EnabledChanged);
            // 
            // aboutUs_Btn
            // 
            this.aboutUs_Btn.Name = "aboutUs_Btn";
            this.aboutUs_Btn.Size = new System.Drawing.Size(67, 20);
            this.aboutUs_Btn.Text = "About us";
            this.aboutUs_Btn.Click += new System.EventHandler(this.aboutUsBtn_Click);
            // 
            // clear_Btn
            // 
            this.clear_Btn.Name = "clear_Btn";
            this.clear_Btn.Size = new System.Drawing.Size(115, 20);
            this.clear_Btn.Text = "Clear Search\\Filter";
            this.clear_Btn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // exit_Btn
            // 
            this.exit_Btn.Name = "exit_Btn";
            this.exit_Btn.Size = new System.Drawing.Size(38, 20);
            this.exit_Btn.Text = "Exit";
            this.exit_Btn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // search_Btn
            // 
            this.search_Btn.Name = "search_Btn";
            this.search_Btn.Size = new System.Drawing.Size(54, 20);
            this.search_Btn.Text = "Search";
            this.search_Btn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // textbox_search
            // 
            this.textbox_search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textbox_search.Location = new System.Drawing.Point(425, 2);
            this.textbox_search.Margin = new System.Windows.Forms.Padding(2);
            this.textbox_search.Name = "textbox_search";
            this.textbox_search.Size = new System.Drawing.Size(187, 20);
            this.textbox_search.TabIndex = 6;
            this.textbox_search.TextChanged += new System.EventHandler(this.textbox_search_TextChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(657, 444);
            this.Controls.Add(this.textbox_search);
            this.Controls.Add(this.userData_grid);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximumSize = new System.Drawing.Size(677, 487);
            this.MinimumSize = new System.Drawing.Size(677, 487);
            this.Name = "MainForm";
            this.Text = "File Handling System";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.userData_grid)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView userData_grid;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem new_Btn;
        private System.Windows.Forms.ToolStripMenuItem update_Btn;
        private System.Windows.Forms.ToolStripMenuItem delete_Btn;
        private System.Windows.Forms.ToolStripMenuItem clear_Btn;
        private System.Windows.Forms.ToolStripMenuItem aboutUs_Btn;
        private System.Windows.Forms.ToolStripMenuItem exit_Btn;
        private System.Windows.Forms.TextBox textbox_search;
        private System.Windows.Forms.ToolStripMenuItem search_Btn;
    }
}

