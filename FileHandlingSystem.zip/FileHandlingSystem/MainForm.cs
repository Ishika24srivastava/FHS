﻿using FileHandlingSystem.BL;
using FileHandlingSystem.Resources;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using FileHandlingSystem.UI;
using FIleHandlingSystem.VO;

namespace FileHandlingSystem
{
    /// <summary>
    /// partial class for main form
    /// </summary>
    public partial class MainForm : Form
    {
        
        InputDataForm userForm;                              //user form object to open User forms
        clsResoucresModuleResources rsc;                                      // Resource class object to use the provided function
        private ValueLayerObject vlo;                      //Object to move the data between the various classes and DLL's

        /// <summary>
        /// COnstructor function whcih will be invoked when an object of this class is created
        /// </summary>
        public MainForm()
        {
             clsBusinessLogicBL bl = new clsBusinessLogicBL();
            vlo = new ValueLayerObject();
            rsc = new clsResoucresModuleResources();
            if (bl.SetConfigurations(vlo))
            {
                AuthenticationForm authentication = new AuthenticationForm(vlo);
                authentication.ShowDialog();
                if (authentication.validated)
                {
                    InitializeComponent();
                }
                else
                {
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show(rsc.GetEnumDescription(Messages.configfilenotexist), rsc.GetEnumDescription(MessageCaptions.configfilenotexist), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            InitializeElements();
        }

        /// <summary>
        ///Disable button of Main Form for the Guest user, to make the form readonly
        /// </summary>
        private void EnableFunctionality()
        {
            if (vlo.userType == UserTypes.GuestUser)
            {
                new_Btn.Enabled = false;
                update_Btn.Enabled = false;
                delete_Btn.Enabled = false;
            }
        }

        /// <summary>
        /// Intialize the elements of main form
        /// </summary>
        private void InitializeElements()
        {
            if (!clsBusinessLogicBL.Initialize(vlo))
            {
                this.Close();
            }

            userForm = new InputDataForm(vlo);
            vlo.serialNumber = 1;
            vlo.values = null;

            clsUserInterfaceUI.AddColumnInGrid(userData_grid, vlo);
            delete_Btn.Enabled = false;
            update_Btn.Enabled = false;
            clear_Btn.Enabled = false;
            ExtractData();
            EnableFunctionality();

            userForm.Closed += (sender, e) =>
            {
                ExtractData();
            };
        }

        /// <summary>
        /// Extract the Data from the Record and insert that data into the Data grid view
        /// </summary>
        public void ExtractData()
        {
            if (vlo.records.Count > 0)
            {
                clsUserInterfaceUI.ExtractDataIntoGrid(userData_grid, vlo, rsc);

                delete_Btn.Enabled = false;
                update_Btn.Enabled = false;
            }

            new_Btn.Enabled = true;
            userData_grid.Rows[0].Selected = false;
            userData_grid.Rows[userData_grid.Rows.Count - 1].Cells[0].Selected = true;
        }

        /// <summary>
        /// FUnction to add the Array of objects to the value array
        /// </summary>
        /// <param name="array"></param>
        private void InsertDataToValues(object[] array)
        {
            for (int i = 0; i < 10; i++)
            {
                object data = array[i];
                if (i == 5)
                {
                    if (data?.ToString() == "")
                    {
                        data = "01/01/1800";
                    }
                }
                else if (i == 6)
                {
                    string qualificationstring = rsc.GetEnumIndexFromDescription<Qualification>(data?.ToString());
                    if (qualificationstring != null)
                    {
                        data = qualificationstring;
                    }
                }
                else if (i == 8)
                {
                    if (data?.ToString() == "")
                    {
                        data = "01/01/1800";
                    }
                }
                vlo.values[i] = data?.ToString();
            }
        }

        
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            clsBusinessLogicBL.ReleaseObjects(vlo);
        }

        
               /// <summary>
        /// Function to Add the Cross Button When Data is entered in the filter row cell
        /// </summary>
        /// <param name="cell">Cell, where data is entered</param>
        private void AddCrossButton(DataGridViewCell cell)
        {
            // Create a cross button
            Button crossButton = new Button();
            crossButton.Text = "✖";
            crossButton.BackColor = Color.Transparent; // Make the button background transparent
            crossButton.FlatStyle = FlatStyle.Flat; // Make the button flat style
            crossButton.FlatAppearance.BorderSize = 0; // Remove the border
            crossButton.Click += CrossButton_Click; // Attach click event handler
            crossButton.Tag = cell;

            UpdateButtonPosition(crossButton, cell);
            // Add the button to the DataGridView
            userData_grid.Controls.Add(crossButton);
        }

        /// <summary>
        /// Function to Remove all the cross button from the filter row
        /// </summary>
        /// <param name="cell"></param>
        private void RemoveCrossButton(DataGridViewCell cell)
        {
            // Remove any existing cross button from the cell
            foreach (Control control in userData_grid.Controls)
            {
                if (control is Button button && userData_grid.GetCellDisplayRectangle(cell.ColumnIndex, cell.RowIndex, false).Contains(button.Bounds))
                {
                    userData_grid.Controls.Remove(button);
                    button.Dispose(); // Dispose the button to release resources
                }
            }
        }

        /// <summary>
        /// Event to remove single filter from the filter row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CrossButton_Click(object sender, EventArgs e)
        {
            Button crossButton = (Button)sender;
            DataGridViewCell cell = (DataGridViewCell)crossButton.Tag;
            cell.Value = null;

            // Remove the cross button
            userData_grid.Controls.Remove(crossButton);
            crossButton.Dispose(); // Dispose the button to release resources

            clsUserInterfaceUI.ShowAllRows(userData_grid);
            foreach (DataGridViewCell currentcell in userData_grid.Rows[0].Cells)
            {
                if (currentcell.Value != null)
                {
                    clsUserInterfaceUI.HideRowsWithEmptyCells(currentcell.ColumnIndex, currentcell.Value, userData_grid);
                }
            }
        }

       
        private void textbox_search_TextChanged(object sender, EventArgs e)
        {
            if (textbox_search.Text.Length > 3)
            {
                clsUserInterfaceUI.SearchRowsWithSearchText(textbox_search.Text, userData_grid);
            }

            if (textbox_search.Text.Length == 1)
            {
                foreach (DataGridViewCell cell in userData_grid.Rows[0].Cells)
                {
                    cell.Value = "";
                    RemoveCrossButton(cell);
                }
                ExtractData();
            }
            clear_Btn.Enabled = true;
        }

      
        private void grd_userData_SortCompare(object sender, DataGridViewSortCompareEventArgs e)
        {
            if (e.RowIndex1 == 0)
            {
                e.Handled = true;
            }
        }

        private void grd_userData_Scroll(object sender, ScrollEventArgs e)
        {
            foreach (Control control in userData_grid.Controls)
            {
                if (control is Button)
                {
                    UpdateButtonPosition((Button)control, (DataGridViewCell)control.Tag);
                }
            }
        }

        /// <summary>
        /// Function to Update Button Position When data grid view is scrolled
        /// </summary>
        /// <param name="button"></param>
        /// <param name="cell"></param>
        private void UpdateButtonPosition(Button button, DataGridViewCell cell)
        {
            int cellHeight = cell.Size.Height;
            int buttonSize = 20; // Assuming button size is 20x20
            int buttonTop = userData_grid.GetCellDisplayRectangle(cell.ColumnIndex, cell.RowIndex, false).Top + (cellHeight - buttonSize) / 2;
            int buttonLeft = userData_grid.GetCellDisplayRectangle(cell.ColumnIndex, cell.RowIndex, false).Right - buttonSize - 2; // Add a margin of 2 pixels
            button.Bounds = new Rectangle(buttonLeft, buttonTop, buttonSize, buttonSize);
        }

        private void btn_new_EnabledChanged(object sender, EventArgs e)
        {
            EnableFunctionality();
        }

        private void btn_update_EnabledChanged(object sender, EventArgs e)
        {
            EnableFunctionality();
        }

        private void btn_delete_EnabledChanged(object sender, EventArgs e)
        {
            EnableFunctionality();
        }

        private void userData_grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void newBtn_Click(object sender, EventArgs e)
        {
            vlo.UserFormType = "New";
            userForm.Text = rsc.GetEnumDescription(Title.addeditform);
            userForm.ShowDialog();

        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            vlo.UserFormType = "Update";
            userForm.Text = rsc.GetEnumDescription(Title.addeditform);
            userForm.ShowDialog();

        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (vlo.values != null)
            {
                DialogResult wantToDelete = MessageBox.Show(rsc.GetEnumDescription(Messages.deleteRecord), rsc.GetEnumDescription(MessageCaptions.deleteRecord), MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (wantToDelete == DialogResult.Yes)
                {
                    clsEmployeeVO vo = new clsEmployeeVO();
                    clsBusinessLogicBL bl = new clsBusinessLogicBL();
                    vo.editMode = EditMode.Delete;
                    if (bl.Save(vo, vlo))
                    {
                        ExtractData();
                    }
                    else
                    {
                        MessageBox.Show("Data not deleted check: " + vo.userDefineError);
                    }
                }
            }

        }

        private void aboutUsBtn_Click(object sender, EventArgs e)
        {
            AboutUs aboutUs = new AboutUs();
            aboutUs.ShowDialog();

        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            textbox_search.Clear();

            foreach (DataGridViewCell cell in userData_grid.Rows[0].Cells)
            {
                cell.Value = "";
                RemoveCrossButton(cell);
            }

            ExtractData();
            clear_Btn.Enabled = false;

        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            if (textbox_search.Text.Length > 0)
            {
                clsUserInterfaceUI.SearchRowsWithSearchText(textbox_search.Text, userData_grid);
            }

        }

        private void userData_gridCellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == 0)
            {
                DataGridViewRow selectedRow = userData_grid.Rows[0];

                DataGridViewCell cell = selectedRow.Cells[e.ColumnIndex];

                if (!string.IsNullOrEmpty(cell.Value?.ToString()))
                {
                    // Add a cross button in the cell
                    AddCrossButton(cell);
                }
                userData_grid.Rows[0].Selected = false;
                clsUserInterfaceUI.HideRowsWithEmptyCells(e.ColumnIndex, selectedRow.Cells[e.ColumnIndex].Value, userData_grid);
                clear_Btn.Enabled = true;
            }

        }

        private void userData_gridCellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 1 && e.RowIndex <= userData_grid.Rows.Count)
            {
                DataGridViewRow selectedRow = userData_grid.Rows[e.RowIndex];
                if (selectedRow.Cells["SerialNumber"].Value != null)
                {
                    new_Btn.Enabled = false;
                    update_Btn.Enabled = true;
                    delete_Btn.Enabled = true;
                    vlo.values = new object[10];
                    InsertDataToValues(selectedRow.Cells.Cast<DataGridViewCell>().Select(cell => cell.Value).ToArray());
                }
                else
                {
                    update_Btn.Enabled = false;
                    delete_Btn.Enabled = false;
                    new_Btn.Enabled = true;
                }
            }
            else if (e.RowIndex == 0)
            {
                userData_grid.Rows[0].Selected = false;
            }
        }

        private void userData_gridCellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 1 && e.RowIndex < userData_grid.Rows.Count - 1)
            {
                DataGridViewRow selectedRow = userData_grid.Rows[e.RowIndex];
                vlo.values = new object[10];
                InsertDataToValues(selectedRow.Cells.Cast<DataGridViewCell>().Select(cell => cell.Value).ToArray());
                vlo.UserFormType = "View";
                userForm.Text = rsc.GetEnumDescription(Title.viewOnlyForm);
                userForm.ShowDialog();
            }
            else if (e.RowIndex == 0)
            {
                userData_grid.Rows[userData_grid.Rows.Count - 1].Selected = false;
            }

        }
    }
}
