﻿using System;
using System.Windows.Forms;
using FIleHandlingSystem.VO;
using FileHandlingSystem.Resources;
using FileHandlingSystem.BL;

namespace FileHandlingSystem.UI

{
    /// <summary>
    /// Class consisting of Function to Interact with the data grid view
    /// </summary>
    public class clsUserInterfaceUI
    {
        /// <summary>
        /// Add COlumn Name in the data grid view from column Name enum
        /// </summary>
        /// <param name="userData_grid"></param>
        public static void AddColumnInGrid(DataGridView userData_grid, ValueLayerObject vlo)
        {
            userData_grid.Columns.Clear();
                foreach (ColumnNamesEnum column in Enum.GetValues(typeof(ColumnNamesEnum)))
                {
                    userData_grid.Columns.Add(column.ToString(), column.ToString());
                }
            

            userData_grid.RowHeadersWidth = 25;
        }

        /// <summary>
        /// Extract the data from record into data grid view
        /// </summary>
        /// <param name="userData_grid"></param>
        /// <param name="vlo"></param>
        /// <param name="rsc"></param>
        public static void ExtractDataIntoGrid(DataGridView userData_grid, ValueLayerObject vlo, clsResoucresModuleResources rsc)
        {
            userData_grid.Rows.Clear();
            userData_grid.Rows.Add();
            vlo.userData = new string[vlo.records.Count, 10];
            for (int i = 0; i < vlo.records.Count; i++)
            {
                string[] columnData = new string[10];
                columnData[0] = vlo.records[i].Substring(0, 18).Trim();
                columnData[1] = vlo.records[i].Substring(18, 7).Trim();
                columnData[2] = vlo.records[i].Substring(25, 50).Trim();
                columnData[3] = vlo.records[i].Substring(75, 25).Trim();
                columnData[4] = vlo.records[i].Substring(100, 50).Trim();
                string dob = vlo.records[i].Substring(150, 10).Trim();
                if (dob == "01/01/1800")
                {
                    columnData[5] = "";
                }
                else
                {
                    columnData[5] = dob;
                }
                int index = Convert.ToInt32(vlo.records[i].Substring(160, 2).Trim());
                string qualificationstring = rsc.GetEnumDescription((Qualification)index);
                columnData[6] = qualificationstring;
                columnData[7] = vlo.records[i].Substring(162, 255).Trim();
                string jd = vlo.records[i].Substring(417, 10).Trim();
                if (jd == "01/01/1800")
                {
                    columnData[8] = "";
                }
                else
                {
                    columnData[8] = jd;
                }
                columnData[9] = vlo.records[i].Substring(427, 500).Trim();
                userData_grid.Rows.Add(columnData);
                userData_grid.Rows[userData_grid.Rows.Count - 2].Cells[0].Value = long.Parse(columnData[0]);
            }
            userData_grid.Sort(userData_grid.Columns[0], System.ComponentModel.ListSortDirection.Ascending);
            for (int row = 1; row < userData_grid.Rows.Count - 1; row++)
            {
                for (int column = 0; column < 10; column++)
                {
                    DataGridViewCell cell = userData_grid.Rows[row].Cells[column];
                    if (column == 0)
                    {
                        vlo.userData[row - 1, column] = cell.Value?.ToString();
                    }
                    if (column == 5 && cell.Value?.ToString() == "")
                    {
                        vlo.userData[row - 1, column] = "01/01/1800";
                    }
                    else if (column == 6)
                    {
                        string qualificationstring = rsc.GetEnumIndexFromDescription<Qualification>(cell.Value?.ToString());
                        if (qualificationstring != null)
                        {
                            vlo.userData[row - 1, column] = qualificationstring;
                        }
                        else
                        {
                            vlo.userData[row - 1, column] = cell.Value?.ToString();
                        }
                    }
                    else if (column == 8 && cell.Value?.ToString() == "")
                    {
                        vlo.userData[row - 1, column] = "01/01/1800";
                    }
                    else
                    {
                        vlo.userData[row - 1, column] = cell.Value?.ToString();
                    }
                }
                vlo.serialNumber = Convert.ToInt32(vlo.userData[row - 1, 0]) + 1;
            }

        }

        /// <summary>
        /// Function to filter out the rows on column basis
        /// </summary>
        /// <param name="indexOfColumn">index of column where filteration will be done</param>
        /// <param name="data">data based on which filteration is done</param>
        /// <param name="userData_grid"></param>
        public static void HideRowsWithEmptyCells(int indexOfColumn, object data, DataGridView userData_grid)
        {
            if (data != null)
            {
                for (int index = 1; index < userData_grid.Rows.Count - 1; index++)
                {
                    DataGridViewRow selectedRow = userData_grid.Rows[index];
                    if (string.IsNullOrEmpty(selectedRow.Cells[indexOfColumn].Value?.ToString()) || !(selectedRow.Cells[indexOfColumn].Value?.ToString().ToUpper()).Contains(data?.ToString().ToUpper()))
                    {
                        selectedRow.Visible = false;
                    }
                }
            }
        }

        /// <summary>
        /// Function to search text in all the cells of datagrid view
        /// </summary>
        /// <param name="data"></param>
        /// <param name="userData_grid"></param>
        public static void SearchRowsWithSearchText(string data, DataGridView userData_grid)
        {
            for (int index = 1; index < userData_grid.Rows.Count - 1; index++)
            {
                DataGridViewRow selectedRow = userData_grid.Rows[index];
                bool rowVisible = false;
                foreach (DataGridViewCell cell in selectedRow.Cells)
                {
                    if ((cell.Value?.ToString().ToUpper()).Contains(data.ToUpper()))
                    {
                        rowVisible = true;
                        break;
                    }
                }
                if (!rowVisible)
                {
                    selectedRow.Visible = false;
                }
                else
                {
                    selectedRow.Visible = true;
                }
            }
        }

        /// <summary>
        /// Function to make all the rows of datagridview as visible
        /// </summary>
        /// <param name="userData_grid"></param>
        public static void ShowAllRows(DataGridView userData_grid)
        {
            foreach (DataGridViewRow row in userData_grid.Rows)
            {
                row.Visible = true;
            }
        }
    }
}